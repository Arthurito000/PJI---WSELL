
function moverCatalogos(direcao) {
    const lista = document.getElementById("catalogosLista");

    lista.scrollBy({
        left: direcao * 350,
        behavior: "smooth"
    });
}


//*esteira de produto
function moverProdutos(direcao) {
    const lista = document.getElementById("produtosLista");

    lista.scrollBy({
        left: direcao * 500,
        behavior: "smooth"
    });
}